#!/usr/bin/env python3
"""
tournament_bot.py - ChessAgent entry point.

LOCAL INTERFACES ONLY: the `uci` and `fen` modes below are LOCAL interfaces.
The real college tournament protocol has NOT been confirmed.  Once you know it
(stdin/stdout? HTTP? a Python class to import?), only the thin adapter at the
bottom of this file needs to change; ChessBot.choose_move() is the core API.

Usage (see README.md):
  python tournament_bot.py find                       # locate Stockfish
  python tournament_bot.py check                      # engine handshake + timing
  python tournament_bot.py fen --fen "<FEN>"          # print one move (UCI notation)
  python tournament_bot.py uci                        # speak UCI on stdin/stdout

stdout is reserved for protocol output; all logging goes to stderr.
"""
import sys
import time

PROCESS_START = time.perf_counter()   # earliest point we can timestamp from Python


def _windows_process_age_s() -> float:
    """Seconds since this process was created (Windows only; 0.0 if unknown).
    Lets the 'invocation' deadline include interpreter start-up. UNTESTED on Windows
    (written without access to one) - failures are swallowed and ignored."""
    try:
        import ctypes
        from ctypes import wintypes
        k32 = ctypes.windll.kernel32
        k32.GetCurrentProcess.restype = wintypes.HANDLE
        creation, exit_t, kern, user, now = (wintypes.FILETIME() for _ in range(5))
        k32.GetProcessTimes(k32.GetCurrentProcess(), ctypes.byref(creation), ctypes.byref(exit_t),
                            ctypes.byref(kern), ctypes.byref(user))
        k32.GetSystemTimeAsFileTime(ctypes.byref(now))
        to_int = lambda ft: (ft.dwHighDateTime << 32) | ft.dwLowDateTime
        age = (to_int(now) - to_int(creation)) / 1e7
        return age if 0.0 <= age <= 2.0 else 0.0      # sanity cap
    except Exception:
        return 0.0


if sys.platform == "win32":
    PROCESS_START -= _windows_process_age_s()

import argparse
import json
import logging
import threading
from typing import Dict, List, Optional

import chess

from config import Config, find_stockfish, stockfish_candidates
from engine_wrapper import (EngineError, EngineNotFound, EngineTimeout, SearchResult,
                            UCIEngine)

log = logging.getLogger("chessagent")

MIN_SEARCH_MS = 40   # below this remaining time we do not even try the engine

# --------------------------------------------------------------------------
# Weak-but-legal fallback (ONLY used if Stockfish is unavailable / times out)
# --------------------------------------------------------------------------
_VALUE = {chess.PAWN: 1, chess.KNIGHT: 3, chess.BISHOP: 3, chess.ROOK: 5, chess.QUEEN: 9, chess.KING: 0}


def fallback_move(board: chess.Board) -> chess.Move:
    """Instant 1-ply heuristic: mate > promotion/captures > checks; avoid hanging pieces."""
    best, best_score = None, -10 ** 9
    for move in list(board.legal_moves):
        mover = board.piece_type_at(move.from_square) or chess.PAWN
        score = 0.0
        if board.is_capture(move):
            victim = board.piece_type_at(move.to_square) or chess.PAWN   # en passant -> pawn
            score += 10 * _VALUE[victim] - _VALUE[mover]
        if move.promotion:
            score += 8 if move.promotion == chess.QUEEN else 1
        board.push(move)
        if board.is_checkmate():
            score += 10 ** 6
        elif board.is_stalemate() or board.is_insufficient_material():
            score -= 50
        else:
            if board.is_check():
                score += 2
            if board.is_attacked_by(board.turn, move.to_square):   # opponent can hit it
                score -= _VALUE[mover]
        board.pop()
        if score > best_score:
            best, best_score = move, score
    assert best is not None
    return best


# --------------------------------------------------------------------------
# Time budget
# --------------------------------------------------------------------------
def compute_hard_deadline(cfg: Config, scope: str, process_start: float, request_start: float,
                          board: chess.Board, game_spent_ms: float,
                          clock: Optional[Dict[str, int]] = None) -> float:
    """Absolute time.perf_counter() value by which a move MUST be ready to output."""
    limit = cfg.time_limit_ms / 1000.0
    margin = cfg.safety_margin_ms / 1000.0
    if scope == "invocation":
        hard = process_start + limit - margin
    elif scope == "game":
        remaining = max(0.0, limit - game_spent_ms / 1000.0)
        moves_left = max(8, cfg.expected_game_moves - board.fullmove_number + 1)
        per_move = remaining / moves_left
        hard = request_start + per_move - min(margin, per_move * 0.25)
    else:  # "move"
        hard = request_start + limit - margin
    if clock:   # clocks supplied by a UCI "go" can only make the deadline SHORTER
        if "movetime" in clock:
            hard = min(hard, request_start + clock["movetime"] / 1000.0)
        elif "time_left" in clock:
            left = clock["time_left"]
            alloc = left / float(clock.get("movestogo") or 30) + 0.8 * clock.get("inc", 0)
            alloc = min(alloc, left * 0.5)
            hard = min(hard, request_start + alloc / 1000.0)
    return hard


# --------------------------------------------------------------------------
# The bot
# --------------------------------------------------------------------------
class ChessBot:
    def __init__(self, cfg: Config, process_start: Optional[float] = None, default_scope: str = "move"):
        self.cfg = cfg
        self.process_start = process_start if process_start is not None else time.perf_counter()
        self.default_scope = default_scope
        self.engine: Optional[UCIEngine] = None
        self.game_spent_ms = 0.0
        self.last_error: Optional[str] = None
        self.last_timing: Dict[str, float] = {}

    @property
    def scope(self) -> str:
        return self.default_scope if self.cfg.time_scope == "auto" else self.cfg.time_scope

    def new_game(self) -> None:
        self.game_spent_ms = 0.0

    def _engine_alive(self) -> bool:
        return self.engine is not None and self.engine.alive

    def warm_up(self, timeout_s: Optional[float] = None) -> bool:
        """Start the engine now (e.g. on UCI `isready`). Returns True on success."""
        if self._engine_alive():
            return True
        try:
            command = self.cfg.resolve_command()
            if self.engine is None:
                self.engine = UCIEngine(command, threads=self.cfg.threads, hash_mb=self.cfg.hash_mb,
                                        move_overhead_ms=self.cfg.move_overhead_ms,
                                        stop_grace_ms=self.cfg.stop_grace_ms)
            self.engine.start(timeout_s if timeout_s is not None else self.cfg.startup_timeout_s)
            return True
        except (EngineError, FileNotFoundError) as exc:
            self.last_error = str(exc)
            log.warning("engine start failed: %s", exc)
            return False

    def close(self) -> None:
        if self.engine is not None:
            self.engine.close()

    def choose_move(self, board: chess.Board, clock: Optional[Dict[str, int]] = None,
                    stop_event: Optional[threading.Event] = None) -> Optional[SearchResult]:
        """
        Returns None for a terminal position (checkmate / stalemate / draw by rule),
        otherwise a SearchResult whose .move is guaranteed legal.
        Raises EngineError only if fallback is disabled and the engine failed.
        """
        t_req = time.perf_counter()
        if board.is_game_over(claim_draw=False):
            return None
        legal = list(board.legal_moves)
        if not legal:
            return None

        hard = compute_hard_deadline(self.cfg, self.scope, self.process_start, t_req, board,
                                     self.game_spent_ms, clock)
        result: Optional[SearchResult] = None

        if len(legal) == 1:
            result = SearchResult(legal[0], "forced")
        else:
            try:
                if not self._engine_alive():
                    budget = hard - time.perf_counter() - 0.3
                    if budget < 0.2:
                        raise EngineTimeout("not enough time left to start the engine")
                    if not self.warm_up(min(self.cfg.startup_timeout_s, budget)):
                        raise EngineError(self.last_error or "engine failed to start")
                remaining_ms = (hard - time.perf_counter()) * 1000
                if remaining_ms < MIN_SEARCH_MS:
                    raise EngineTimeout("no time left for a search")
                result = self.engine.search(board, int(remaining_ms), hard, stop_event)
            except EngineError as exc:
                self.last_error = str(exc)
                log.warning("engine problem (%s) -> %s", exc,
                            "using legal fallback move" if self.cfg.fallback else "no fallback allowed")
                if not self.cfg.fallback:
                    raise
                result = SearchResult(fallback_move(board), "fallback")

        if result.move not in board.legal_moves:      # last line of defence
            log.error("selected move %s is illegal; replacing with fallback", result.move)
            result = SearchResult(fallback_move(board), "fallback")

        elapsed = (time.perf_counter() - t_req) * 1000
        result.elapsed_ms = elapsed
        self.game_spent_ms += elapsed
        self.last_timing = {"elapsed_ms": elapsed,
                            "since_process_start_ms": (time.perf_counter() - self.process_start) * 1000}
        return result


# --------------------------------------------------------------------------
# Position helpers
# --------------------------------------------------------------------------
def build_board(fen: Optional[str], moves: List[str]) -> chess.Board:
    board = chess.Board() if fen in (None, "", "startpos") else chess.Board(fen)   # ValueError if bad
    if not board.is_valid():
        log.warning("position is not strictly valid: %r (continuing)", board.status())
    for text in moves:
        try:
            move = chess.Move.from_uci(text)
        except ValueError:
            raise ValueError(f"Bad move notation {text!r}")
        if move not in board.legal_moves:
            raise ValueError(f"Illegal move {text} in position {board.fen()}")
        board.push(move)
    return board


# --------------------------------------------------------------------------
# LOCAL INTERFACE 1: one-shot FEN mode  (NOT the tournament protocol)
# --------------------------------------------------------------------------
def run_fen(cfg: Config, args) -> int:
    try:
        board = build_board(args.fen, args.moves or [])
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 3
    bot = ChessBot(cfg, PROCESS_START, default_scope="invocation")
    try:
        result = bot.choose_move(board)
    except EngineError as exc:
        print(f"error: engine failure and fallback disabled: {exc}", file=sys.stderr)
        return 4
    finally:
        bot.close()
    if result is None:
        print("error: position is terminal (no move to play)", file=sys.stderr)
        return 2
    san = board.san(result.move)
    if args.json:
        print(json.dumps({"move": result.move.uci(), "san": san, "source": result.source,
                          "depth": result.depth, "score_cp": result.score_cp, "mate": result.mate,
                          "elapsed_ms": round(result.elapsed_ms, 1),
                          "since_process_start_ms": round((time.perf_counter() - PROCESS_START) * 1000, 1)}))
    else:
        print(san if args.san else result.move.uci())
    sys.stdout.flush()
    log.info("move=%s source=%s depth=%s elapsed=%.0fms", result.move.uci(), result.source,
             result.depth, result.elapsed_ms)
    return 0


# --------------------------------------------------------------------------
# LOCAL INTERFACE 2: UCI mode (acts as a UCI engine; NOT confirmed as the tournament protocol)
# --------------------------------------------------------------------------
def _parse_position(parts: List[str]) -> chess.Board:
    if len(parts) < 2:
        raise ValueError("empty position command")
    moves: List[str] = []
    if "moves" in parts:
        idx = parts.index("moves")
        moves = parts[idx + 1:]
        parts = parts[:idx]
    if parts[1] == "startpos":
        return build_board(None, moves)
    if parts[1] == "fen":
        return build_board(" ".join(parts[2:]), moves)
    raise ValueError(f"unsupported position command: {' '.join(parts)}")


def _parse_go(parts: List[str], turn: bool) -> Optional[Dict[str, int]]:
    vals: Dict[str, int] = {}
    keys = {"wtime", "btime", "winc", "binc", "movestogo", "movetime", "depth", "nodes"}
    i = 1
    while i < len(parts):
        if parts[i] in keys and i + 1 < len(parts):
            try:
                vals[parts[i]] = int(parts[i + 1])
            except ValueError:
                pass
            i += 2
        else:
            i += 1
    if "movetime" in vals:
        return {"movetime": vals["movetime"]}
    mine, inc = ("wtime", "winc") if turn == chess.WHITE else ("btime", "binc")
    if mine in vals:
        clock = {"time_left": vals[mine], "inc": vals.get(inc, 0)}
        if "movestogo" in vals:
            clock["movestogo"] = vals["movestogo"]
        return clock
    return None     # infinite / depth-only: still capped by the configured time limit


def run_uci(cfg: Config) -> int:
    bot = ChessBot(cfg, PROCESS_START, default_scope="move")
    out_lock = threading.Lock()
    stop_event = threading.Event()
    state = {"board": chess.Board(), "error": None}
    worker: List[Optional[threading.Thread]] = [None]

    def out(text: str) -> None:
        with out_lock:
            sys.stdout.write(text + "\n")
            sys.stdout.flush()

    def search_job(board: chess.Board, clock) -> None:
        try:
            res = bot.choose_move(board, clock, stop_event)
            if res is None:
                out("bestmove (none)")
            else:
                if res.depth is not None:
                    score = f"mate {res.mate}" if res.mate is not None else f"cp {res.score_cp or 0}"
                    out(f"info depth {res.depth} score {score} time {int(res.elapsed_ms)}")
                out(f"bestmove {res.move.uci()}")
        except Exception as exc:     # never die silently mid-game
            log.error("search failed: %s", exc)
            out("bestmove (none)")

    def wait_worker(timeout: Optional[float] = None) -> None:
        t = worker[0]
        if t is not None and t.is_alive():
            t.join(timeout)

    try:
        for raw in sys.stdin:
            parts = raw.split()
            if not parts:
                continue
            cmd = parts[0]
            if cmd == "uci":
                out("id name ChessAgent (Stockfish wrapper)")
                out("id author ChessAgent hackathon bot")
                out("uciok")
            elif cmd == "isready":
                wait_worker()
                bot.warm_up()          # pre-start engine so the first move is not penalised
                out("readyok")
            elif cmd == "ucinewgame":
                wait_worker()
                bot.new_game()
                state["board"], state["error"] = chess.Board(), None
            elif cmd == "position":
                wait_worker()
                try:
                    state["board"], state["error"] = _parse_position(parts), None
                except ValueError as exc:
                    state["error"] = str(exc)
                    log.error("bad position: %s", exc)
            elif cmd == "go":
                if worker[0] is not None and worker[0].is_alive():
                    log.warning("ignoring `go` while a search is running (no overlapping searches)")
                    continue
                if state["error"]:
                    out("bestmove (none)")
                    continue
                board = state["board"].copy()
                stop_event.clear()
                worker[0] = threading.Thread(target=search_job, args=(board, _parse_go(parts, board.turn)),
                                             daemon=True)
                worker[0].start()
            elif cmd == "stop":
                stop_event.set()
            elif cmd == "quit":
                stop_event.set()
                wait_worker(1.0)
                break
            elif cmd == "setoption":
                log.debug("setoption ignored: %s", raw.strip())   # config is via env/CLI
            # unknown commands are ignored, as the UCI spec requires
        else:
            # stdin closed (EOF): let any running search finish and print its bestmove
            wait_worker(cfg.time_limit_ms / 1000.0 + 1.0)
    finally:
        bot.close()
    return 0


# --------------------------------------------------------------------------
# Diagnostics
# --------------------------------------------------------------------------
def run_find(cfg: Config) -> int:
    cands = stockfish_candidates(max_seconds=8.0)
    if not cands:
        print("No Stockfish executable found. Search manually, then set STOCKFISH_PATH "
              "(see README).")
        return 1
    chosen = find_stockfish(cfg.stockfish_path)
    print("Candidates (first = auto-detect choice):")
    for p in cands:
        print("  " + p)
    print(f"Selected: {chosen}")
    return 0


def run_check(cfg: Config) -> int:
    t0 = time.perf_counter()
    try:
        command = cfg.resolve_command()
    except FileNotFoundError as exc:
        print(f"FAIL: {exc}")
        return 1
    print(f"Engine command : {command}")
    print(f"Settings       : threads={cfg.threads} hash={cfg.hash_mb}MB limit={cfg.time_limit_ms}ms "
          f"scope={cfg.time_scope} margin={cfg.safety_margin_ms}ms")
    eng = UCIEngine(command, threads=cfg.threads, hash_mb=cfg.hash_mb,
                    move_overhead_ms=cfg.move_overhead_ms, stop_grace_ms=cfg.stop_grace_ms)
    try:
        eng.start(cfg.startup_timeout_s)
    except EngineError as exc:
        print(f"FAIL: UCI handshake failed: {exc}")
        print("Hint: try a different Stockfish build (e.g. avx2 -> x86-64) if the CPU lacks instructions.")
        return 1
    print(f"Engine name    : {eng.name}")
    print(f"Handshake      : OK in {eng.startup_ms:.0f} ms; applied options {eng.applied_options}")
    board = chess.Board()
    res = eng.search(board, 300, time.perf_counter() + 1.0)
    print(f"Test search    : {res.move.uci()} (depth {res.depth}) in {res.elapsed_ms:.0f} ms")
    eng.close()
    print(f"Total          : {(time.perf_counter() - t0) * 1000:.0f} ms  -> ENGINE OK")
    return 0


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------
def main(argv: Optional[List[str]] = None) -> int:
    for stream in (sys.stdout, sys.stdin):
        try:
            stream.reconfigure(newline="\n") if stream is sys.stdout else stream.reconfigure(encoding="utf-8")
        except Exception:
            pass
    def add_common(parser: argparse.ArgumentParser, sub: bool) -> None:
        # Global options are accepted before OR after the sub-command.
        d = {"default": argparse.SUPPRESS} if sub else {}
        parser.add_argument("--stockfish", help="path to the Stockfish executable "
                            "(else STOCKFISH_PATH / auto-detect)", **d)
        parser.add_argument("--time-ms", type=int, help="time limit in ms (default 5000)", **d)
        parser.add_argument("--scope", choices=["auto", "move", "invocation", "game"],
                            help="what the time limit covers (UNCONFIRMED; default auto)", **d)
        parser.add_argument("--margin-ms", type=int, help="safety margin in ms (default 700)", **d)
        parser.add_argument("--threads", type=int, help="Stockfish Threads (default 1)", **d)
        parser.add_argument("--hash", type=int, dest="hash_mb", help="Stockfish Hash in MB (default 16)", **d)
        parser.add_argument("--no-fallback", action="store_true", help="never play the weak fallback move", **d)
        parser.add_argument("-v", "--verbose", action="store_true", help="debug logging to stderr", **d)

    p = argparse.ArgumentParser(description="ChessAgent (Stockfish via python-chess). "
                                            "uci/fen modes are LOCAL interfaces, not the confirmed tournament protocol.")
    add_common(p, sub=False)
    subs = p.add_subparsers(dest="mode")
    add_common(subs.add_parser("uci", help="LOCAL: act as a UCI engine on stdin/stdout (default)"), sub=True)
    f = subs.add_parser("fen", help="LOCAL: print one move for a FEN position")
    add_common(f, sub=True)
    f.add_argument("--fen", default="startpos", help='FEN string or "startpos"')
    f.add_argument("--moves", nargs="*", help="UCI moves to play from the FEN, e.g. e2e4 e7e5")
    f.add_argument("--san", action="store_true", help="print SAN instead of UCI notation")
    f.add_argument("--json", action="store_true", help="print a JSON object with timing info")
    add_common(subs.add_parser("find", help="list Stockfish executables found on this machine"), sub=True)
    add_common(subs.add_parser("check", help="verify the engine handshake and a short search"), sub=True)
    args = p.parse_args(argv)

    try:
        cfg = Config.from_env(stockfish_path=args.stockfish, time_limit_ms=args.time_ms,
                              time_scope=args.scope, safety_margin_ms=args.margin_ms,
                              threads=args.threads, hash_mb=args.hash_mb,
                              fallback=False if args.no_fallback else None,
                              verbose=True if args.verbose else None)
    except ValueError as exc:
        print(f"config error: {exc}", file=sys.stderr)
        return 3
    logging.basicConfig(stream=sys.stderr, level=logging.DEBUG if cfg.verbose else logging.WARNING,
                        format="%(levelname)s %(name)s: %(message)s")

    mode = args.mode or "uci"
    if mode == "fen":
        return run_fen(cfg, args)
    if mode == "find":
        return run_find(cfg)
    if mode == "check":
        return run_check(cfg)
    return run_uci(cfg)


if __name__ == "__main__":
    sys.exit(main())
