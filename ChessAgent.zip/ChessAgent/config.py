"""
config.py - settings and Stockfish discovery for ChessAgent.

Everything here is overridable with environment variables or CLI flags, so you
can change the time budget / threads / hash without editing code.

TIME LIMIT MEANING IS UNCONFIRMED.  "5 seconds" could be:
  * per move            -> time_scope = "move"        (clock restarts every move)
  * per agent invocation-> time_scope = "invocation"  (clock starts at process start,
                           includes Python start-up, engine start-up, parsing, search)
  * per whole game      -> time_scope = "game"        (one shared 5 s budget; split
                           across the remaining moves)
Default "auto" = "invocation" for the one-shot `fen` mode (strictest for a
one-shot process) and "move" for the long-running `uci` mode.  Set the scope
explicitly once you have read the official rules.
"""
from __future__ import annotations

import os
import shutil
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator, List, Optional

# Optional permanent path.  Leave "" to auto-detect.  Example (Windows):
# LOCAL_STOCKFISH_PATH = r"C:\Users\you\Desktop\stockfish\stockfish-windows-x86-64-avx2.exe"
LOCAL_STOCKFISH_PATH = ""

VALID_SCOPES = ("auto", "move", "invocation", "game")


def _env_int(name: str, default: int) -> int:
    raw = os.environ.get(name)
    if raw is None or raw.strip() == "":
        return default
    try:
        return int(raw)
    except ValueError:
        raise ValueError(f"Environment variable {name}={raw!r} is not an integer")


def _env_bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None or raw.strip() == "":
        return default
    return raw.strip().lower() in ("1", "true", "yes", "on")


@dataclass
class Config:
    stockfish_path: Optional[str] = None      # explicit path (arg / env / LOCAL_STOCKFISH_PATH)
    engine_command: Optional[List[str]] = None  # full command override (used by tests)
    time_limit_ms: int = 5000                 # the tournament limit (meaning set by time_scope)
    time_scope: str = "auto"                  # auto | move | invocation | game
    safety_margin_ms: int = 700               # reserved for interpreter start/exit, pipes, output
    stop_grace_ms: int = 60                   # max time reserved for Stockfish to answer "stop"
    startup_timeout_s: float = 3.0            # max time for the UCI handshake
    threads: int = 1                          # conservative; raise after confirming limits
    hash_mb: int = 16                         # conservative; raise after confirming limits
    move_overhead_ms: int = 50                # Stockfish "Move Overhead"
    expected_game_moves: int = 40             # only used for time_scope="game"
    fallback: bool = True                     # legal fallback move if engine fails/times out
    verbose: bool = False

    @classmethod
    def from_env(cls, **overrides) -> "Config":
        cfg = cls()
        cfg.stockfish_path = os.environ.get("STOCKFISH_PATH") or LOCAL_STOCKFISH_PATH or None
        cfg.time_limit_ms = _env_int("CHESS_TIME_LIMIT_MS", cfg.time_limit_ms)
        cfg.time_scope = os.environ.get("CHESS_TIME_SCOPE", cfg.time_scope).strip().lower()
        cfg.safety_margin_ms = _env_int("CHESS_SAFETY_MARGIN_MS", cfg.safety_margin_ms)
        cfg.threads = _env_int("CHESS_THREADS", cfg.threads)
        cfg.hash_mb = _env_int("CHESS_HASH_MB", cfg.hash_mb)
        cfg.move_overhead_ms = _env_int("CHESS_MOVE_OVERHEAD_MS", cfg.move_overhead_ms)
        cfg.expected_game_moves = _env_int("CHESS_EXPECTED_MOVES", cfg.expected_game_moves)
        cfg.fallback = _env_bool("CHESS_FALLBACK", cfg.fallback)
        cfg.verbose = _env_bool("CHESS_VERBOSE", cfg.verbose)
        for key, value in overrides.items():
            if value is not None:
                if not hasattr(cfg, key):
                    raise AttributeError(f"Unknown config field: {key}")
                setattr(cfg, key, value)
        cfg.validate()
        return cfg

    def validate(self) -> None:
        if self.time_scope not in VALID_SCOPES:
            raise ValueError(f"time_scope must be one of {VALID_SCOPES}, got {self.time_scope!r}")
        self.time_limit_ms = max(300, int(self.time_limit_ms))
        self.safety_margin_ms = max(0, min(int(self.safety_margin_ms), self.time_limit_ms - 200))
        self.stop_grace_ms = max(20, int(self.stop_grace_ms))
        # Never ask for more threads than the machine has; never assume 4.
        self.threads = max(1, min(int(self.threads), os.cpu_count() or 1, 64))
        self.hash_mb = max(1, min(int(self.hash_mb), 2048))
        self.move_overhead_ms = max(0, int(self.move_overhead_ms))

    def resolve_command(self) -> List[str]:
        """Return the command used to launch the engine, or raise FileNotFoundError."""
        if self.engine_command:
            return list(self.engine_command)
        path = find_stockfish(self.stockfish_path)
        if not path:
            if self.stockfish_path:
                raise FileNotFoundError(f"Stockfish not found at configured path: {self.stockfish_path}")
            raise FileNotFoundError(
                "Stockfish executable not found. Set STOCKFISH_PATH (see README) or run "
                "`python tournament_bot.py find`."
            )
        return [path]


# --------------------------------------------------------------------------
# Stockfish discovery
# --------------------------------------------------------------------------
_SKIP_DIRS = {"node_modules", "__pycache__", "appdata", "windows", "$recycle.bin",
              "site-packages", ".venv", "venv", "system32", "program files (x86)"}
_BUILD_RANK = ("avx2", "bmi2", "sse41", "ssse3", "popcnt", "x86-64")  # preference order


def _looks_like_stockfish(filename: str) -> bool:
    low = filename.lower()
    if not low.startswith("stockfish"):
        return False
    if os.name == "nt":
        return low.endswith(".exe")
    return "." not in low


def _walk(root: str, max_depth: int, deadline: float) -> Iterator[str]:
    if not os.path.isdir(root):
        return
    base = root.rstrip("\\/").count(os.sep)
    for dirpath, dirnames, filenames in os.walk(root):
        if time.monotonic() > deadline:
            return
        if dirpath.count(os.sep) - base >= max_depth:
            dirnames[:] = []
        dirnames[:] = [d for d in dirnames if not d.startswith(".") and d.lower() not in _SKIP_DIRS]
        for name in filenames:
            if _looks_like_stockfish(name):
                yield os.path.join(dirpath, name)


def _rank(path: str) -> int:
    low = path.lower()
    for i, tag in enumerate(_BUILD_RANK):
        if tag in low:
            return i
    return len(_BUILD_RANK)


def stockfish_candidates(max_seconds: float = 3.0) -> List[str]:
    """Every Stockfish executable we can find (best guess first)."""
    found: List[str] = []

    def add(p: Optional[str]) -> None:
        if p and os.path.isfile(p) and p not in found:
            found.append(p)

    add(os.environ.get("STOCKFISH_PATH"))
    add(LOCAL_STOCKFISH_PATH or None)
    here = Path(__file__).resolve().parent
    deadline = time.monotonic() + max_seconds
    for p in _walk(str(here), 3, deadline):
        add(p)
    for exe in ("stockfish", "stockfish.exe"):
        add(shutil.which(exe))
    home = Path.home()
    roots = [home / "Desktop", home / "Downloads", home / "Documents",
             home / "OneDrive" / "Desktop", home / "OneDrive" / "Downloads"]
    if os.name == "nt":
        roots += [Path("C:/stockfish"), Path("C:/Program Files"), Path("C:/Tools"), Path("C:/")]
    else:
        add("/usr/games/stockfish")
        add("/usr/bin/stockfish")
        add("/usr/local/bin/stockfish")
        roots += [home]
    for root in roots:
        depth = 1 if str(root) in ("C:\\", "C:/") else 4
        extra = sorted(_walk(str(root), depth, deadline), key=_rank)
        for p in extra:
            add(p)
    return found


def find_stockfish(explicit: Optional[str] = None) -> Optional[str]:
    """
    If `explicit` is given (CLI flag / STOCKFISH_PATH / LOCAL_STOCKFISH_PATH) it is
    used as-is and NEVER silently replaced by another binary.  Otherwise auto-detect.
    """
    if explicit:
        explicit = os.path.expandvars(os.path.expanduser(explicit.strip().strip('"')))
        if os.path.isfile(explicit):
            return explicit
        return shutil.which(explicit)
    cands = stockfish_candidates()
    return cands[0] if cands else None
