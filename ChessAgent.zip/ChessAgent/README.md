# ChessAgent

Python + python-chess agent that delegates move selection to your existing Stockfish
executable, with a strict, configurable time deadline, move validation, and a
legal-move fallback.

> **Protocol status: UNCONFIRMED.** The `uci` and `fen` modes are **local interfaces**
> for testing. Nobody has confirmed what the college tournament actually calls
> (stdin/stdout? a Python class? HTTP?). Read the official rules, then adapt only the
> thin adapter at the bottom of `tournament_bot.py`; `ChessBot.choose_move(board)` is the core API.

## Files

| File | Purpose |
|---|---|
| `tournament_bot.py` | Entry point: `ChessBot`, time budget, `uci` / `fen` / `find` / `check` commands |
| `engine_wrapper.py` | Deadline-strict UCI wrapper (stop, kill, restart, move validation) |
| `config.py` | Settings (env vars / flags) and Stockfish discovery |
| `test_suite.py` | Tests (real Stockfish + fake misbehaving engines) |
| `requirements.txt` | `chess` (python-chess) |

## What does "5 seconds" mean? (decide before the tournament)

The code does **not** assume. Pick the scope that matches the official rules:

| Rules say | Use | Clock starts at |
|---|---|---|
| 5 s **per move** | `--scope move` | the moment the move is requested |
| 5 s **per agent run** (process launched once per move) | `--scope invocation` | process start (includes Python start, engine start, parsing, search, output) |
| 5 s **for the whole game** | `--scope game` | shared budget split over remaining moves (play is very weak at this speed) |

Default `auto` = `invocation` for `fen` mode (strictest for a one-shot process) and
`move` for `uci` mode. The deadline is `limit - safety margin` (default margin 700 ms, for
interpreter start/exit and pipe latency). Change with `--time-ms`, `--scope`, `--margin-ms`.
If you cannot confirm the meaning, leave the defaults: they are the conservative choice.

## Windows PowerShell: setup

```powershell
cd "$HOME\Desktop\ChessAgent"
py -3 -m pip install -r requirements.txt      # if `py` is missing, use: python -m pip install -r requirements.txt
```

## Windows PowerShell: locate Stockfish

```powershell
# 1) Search your profile for any Stockfish executable
Get-ChildItem -Path $HOME -Recurse -Filter "stockfish*.exe" -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName

# 2) Or let the agent look (Desktop, Downloads, project folder, PATH, C:\...)
python tournament_bot.py find

# 3) Tell the agent which one to use (this PowerShell window only)
$env:STOCKFISH_PATH = "C:\full\path\to\stockfish-windows-x86-64-avx2.exe"

# Optional: make it permanent (applies to NEW windows)
setx STOCKFISH_PATH "C:\full\path\to\stockfish-windows-x86-64-avx2.exe"
```

An explicitly configured path is **never** silently replaced by a different binary.
Several builds in the folder? Prefer `avx2` (or `bmi2`); if `check` fails with a crash/timeout,
try the plain `x86-64` build (your CPU may lack the instructions).

## Windows PowerShell: test the engine

```powershell
python tournament_bot.py check                       # handshake + short search + timings
python -m unittest -v test_suite                     # full suite (~30 s)
python tournament_bot.py fen --fen startpos          # prints ONE move, e.g. e2e4
python tournament_bot.py fen --fen "6k1/5ppp/8/8/8/8/8/R5K1 w - - 0 1"   # expect a1a8
python tournament_bot.py fen --fen startpos --json   # includes elapsed times
```

Run `check` once before the event: the **first** launch of a freshly downloaded `.exe`
can be slow (antivirus scan / cold disk cache) and may exceed the start-up timeout. Warm it up.

## Windows PowerShell: launch the agent

```powershell
# One-shot (FEN in, one move out) - LOCAL interface
python tournament_bot.py fen --fen "<FEN>" [--moves e2e4 e7e5 ...]

# UCI engine on stdin/stdout - LOCAL interface (usable from any UCI GUI / harness)
python tournament_bot.py uci

# Quick UCI smoke test from PowerShell (no `quit` line: EOF lets the search finish)
"uci","isready","position startpos moves e2e4 e7e5","go movetime 1000" | python tournament_bot.py uci
```

Exit codes for `fen`: `0` move printed, `2` terminal position (no move), `3` bad input, `4` engine
failure with `--no-fallback`. stdout carries only the move; logs go to stderr (`-v` for debug).

## Settings

Flags work before or after the sub-command. Environment variables are equivalent.

| Flag | Env var | Default | Notes |
|---|---|---|---|
| `--stockfish` | `STOCKFISH_PATH` | auto-detect | explicit path is never replaced silently |
| `--time-ms` | `CHESS_TIME_LIMIT_MS` | 5000 | the tournament limit |
| `--scope` | `CHESS_TIME_SCOPE` | auto | move / invocation / game |
| `--margin-ms` | `CHESS_SAFETY_MARGIN_MS` | 700 | reserved for start/exit/output |
| `--threads` | `CHESS_THREADS` | 1 | capped at the machine's CPU count; raise only if rules allow |
| `--hash` | `CHESS_HASH_MB` | 16 | raise only if rules allow |
| `--no-fallback` | `CHESS_FALLBACK=0` | fallback on | use if the rules forbid the agent choosing its own move on engine failure |
| `-v` | `CHESS_VERBOSE=1` | off | debug logs to stderr |

## Behaviour

* Board is rebuilt from FEN + move history (repetition history preserved); illegal input is rejected.
* No move is returned for checkmate, stalemate, insufficient material, 75-move / fivefold positions.
* Only one search at a time; `go infinite` is capped by the configured limit.
* Engine is reused between moves (UCI mode), restarted if it dies.
* Every engine move is checked against the legal moves; illegal output triggers the fallback.
* At `deadline - ~60 ms` the engine gets `stop`; if it still does not answer by the deadline it is
  killed and the last principal-variation move (or the fallback) is used.
* Single legal move: returned instantly without starting a search.
* The fallback (1-ply heuristic) is **much weaker** than Stockfish; it is only for failures
  (a warning is printed to stderr when it is used).

## Known limitations

* Tournament protocol and the meaning of the 5 s limit are unconfirmed (see above).
* Developed and tested on Linux with Stockfish 16 and 1 CPU core. **Not run on Windows or with Stockfish 19.**
  Windows-specific code (hidden console window, process-start timestamp, path search) is
  written defensively but untested; use `check` and the test suite on your machine.
* Timings depend on your CPU/disk/antivirus. Re-measure with the commands above.
* No opening book, tablebases or pondering. No guarantee of winning any game.
