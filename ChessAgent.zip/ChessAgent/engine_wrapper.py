"""
engine_wrapper.py - minimal, deadline-strict UCI wrapper around Stockfish.

Why not chess.engine?  We need hard guarantees: every wait is bounded by an
absolute deadline, a hung engine is killed, and nothing ever blocks forever.

All logging goes to stderr via `logging`; stdout is never touched here.
"""
from __future__ import annotations

import logging
import os
import queue
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass
from typing import List, Optional, Sequence

import chess

log = logging.getLogger("chessagent.engine")


class EngineError(RuntimeError):
    """Any engine failure (the bot may fall back to a legal move)."""


class EngineNotFound(EngineError):
    pass


class EngineTimeout(EngineError):
    pass


class IllegalEngineMove(EngineError):
    pass


@dataclass
class SearchResult:
    move: chess.Move
    source: str                       # stockfish | stockfish-partial | forced | fallback
    depth: Optional[int] = None
    score_cp: Optional[int] = None
    mate: Optional[int] = None
    elapsed_ms: float = 0.0


class UCIEngine:
    def __init__(self, command: Sequence[str], *, threads: int = 1, hash_mb: int = 16,
                 move_overhead_ms: int = 50, stop_grace_ms: int = 150):
        self.command = list(command)
        self.threads = threads
        self.hash_mb = hash_mb
        self.move_overhead_ms = move_overhead_ms
        self.stop_grace_ms = stop_grace_ms
        self.name = ""
        self.options: set = set()
        self.startup_ms: Optional[float] = None
        self.applied_options: dict = {}
        self._proc: Optional[subprocess.Popen] = None
        self._q: "queue.Queue[Optional[str]]" = queue.Queue()

    # ------------------------------------------------------------------ lifecycle
    @property
    def alive(self) -> bool:
        return self._proc is not None and self._proc.poll() is None

    def start(self, timeout_s: float = 3.0) -> None:
        """Launch the engine and complete the UCI handshake within timeout_s."""
        self.close(fast=True)
        t0 = time.perf_counter()
        deadline = t0 + timeout_s
        exe = self.command[0]
        if not (os.path.isfile(exe) or shutil.which(exe)):
            raise EngineNotFound(f"Engine executable not found: {exe}")
        kwargs = dict(stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                      text=True, encoding="utf-8", errors="replace", bufsize=1)
        if os.name == "nt":
            kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
        try:
            proc = subprocess.Popen(self.command, **kwargs)
        except OSError as exc:
            raise EngineNotFound(f"Cannot launch engine {exe}: {exc}") from exc
        self._proc = proc
        self._q = queue.Queue()
        threading.Thread(target=self._read_loop, args=(proc, self._q), daemon=True).start()
        try:
            self._send("uci")
            for line in self._wait_for("uciok", deadline):
                if line.startswith("id name "):
                    self.name = line[8:]
                elif line.startswith("option name "):
                    # "option name Move Overhead type spin ..."
                    rest = line[len("option name "):]
                    self.options.add(rest.split(" type ")[0].strip())
            wanted = {"Threads": self.threads, "Hash": self.hash_mb,
                      "Move Overhead": self.move_overhead_ms}
            for opt, val in wanted.items():
                if opt in self.options:        # only touch options the engine really has
                    self._send(f"setoption name {opt} value {val}")
                    self.applied_options[opt] = val
            self._send("isready")
            for _ in self._wait_for("readyok", deadline):
                pass
        except EngineError:
            self.close(fast=True)
            raise
        self.startup_ms = (time.perf_counter() - t0) * 1000
        log.debug("engine %r ready in %.0f ms, options=%s", self.name, self.startup_ms, self.applied_options)

    def close(self, fast: bool = False) -> None:
        proc, self._proc = self._proc, None
        if proc is None:
            return
        try:
            if proc.poll() is None:
                if not fast:
                    try:
                        proc.stdin.write("quit\n")
                        proc.stdin.flush()
                        proc.wait(timeout=0.15)
                    except Exception:
                        pass
                if proc.poll() is None:
                    proc.kill()
                    try:
                        proc.wait(timeout=1.0)
                    except Exception:
                        pass
        finally:
            for stream in (proc.stdin, proc.stdout):
                try:
                    stream.close()
                except Exception:
                    pass

    def __enter__(self) -> "UCIEngine":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    # ------------------------------------------------------------------ plumbing
    @staticmethod
    def _read_loop(proc: subprocess.Popen, q: "queue.Queue[Optional[str]]") -> None:
        try:
            for line in proc.stdout:
                q.put(line.strip())
        except Exception:
            pass
        finally:
            q.put(None)  # EOF marker

    def _send(self, text: str) -> None:
        try:
            self._proc.stdin.write(text + "\n")
            self._proc.stdin.flush()
        except (OSError, ValueError, AttributeError) as exc:
            raise EngineError(f"Engine pipe broken while sending {text!r}: {exc}") from exc

    def _wait_for(self, token: str, deadline: float):
        """Yield lines until one equals `token`; raise on EOF or deadline."""
        while True:
            remaining = deadline - time.perf_counter()
            if remaining <= 0:
                raise EngineTimeout(f"Timed out waiting for {token!r}")
            try:
                line = self._q.get(timeout=min(remaining, 0.05))
            except queue.Empty:
                continue
            if line is None:
                raise EngineError(f"Engine exited while waiting for {token!r}")
            if line == token:
                return
            yield line

    def _drain(self) -> None:
        try:
            while True:
                self._q.get_nowait()
        except queue.Empty:
            pass

    # ------------------------------------------------------------------ search
    def search(self, board: chess.Board, movetime_ms: int, hard_deadline: float,
               stop_event: Optional[threading.Event] = None) -> SearchResult:
        """
        Search `board`.  `hard_deadline` is an absolute time.perf_counter() value by
        which this method MUST have returned or raised.  At (deadline - grace) we send
        "stop"; at the deadline a non-answering engine is killed.
        """
        if not self.alive:
            raise EngineError("Engine is not running")
        t0 = time.perf_counter()
        # reserve at most 25% of the budget for the "stop" round-trip (tiny budgets stay usable)
        grace = min(self.stop_grace_ms / 1000.0, max(0.0, hard_deadline - t0) * 0.25)
        soft_deadline = max(t0, hard_deadline - grace)
        movetime = int(min(movetime_ms, (soft_deadline - t0) * 1000))
        movetime = max(movetime, 1)

        self._drain()
        root = board.root()
        cmd = f"position fen {root.fen()}"
        if board.move_stack:
            cmd += " moves " + " ".join(m.uci() for m in board.move_stack)
        self._send(cmd)
        self._send(f"go movetime {movetime}")

        stop_sent = False
        depth = score_cp = mate = None
        partial_move: Optional[chess.Move] = None
        best_move: Optional[chess.Move] = None

        while True:
            now = time.perf_counter()
            if not stop_sent and (now >= soft_deadline or (stop_event is not None and stop_event.is_set())):
                self._send("stop")
                stop_sent = True
            if now >= hard_deadline:
                self.close(fast=True)  # hung engine: kill it, next call restarts it
                if partial_move is not None and partial_move in board.legal_moves:
                    log.warning("engine did not answer in time; using last principal-variation move")
                    return SearchResult(partial_move, "stockfish-partial", depth, score_cp, mate,
                                        (time.perf_counter() - t0) * 1000)
                raise EngineTimeout("Engine did not return a move before the deadline")
            try:
                line = self._q.get(timeout=0.02)
            except queue.Empty:
                continue
            if line is None:
                raise EngineError("Engine exited during search")
            if line.startswith("info "):
                tok = line.split()
                if "multipv" in tok and tok[tok.index("multipv") + 1] != "1":
                    continue
                if "depth" in tok:
                    try:
                        depth = int(tok[tok.index("depth") + 1])
                    except (ValueError, IndexError):
                        pass
                if "score" in tok:
                    i = tok.index("score")
                    try:
                        if tok[i + 1] == "cp":
                            score_cp, mate = int(tok[i + 2]), None
                        elif tok[i + 1] == "mate":
                            mate, score_cp = int(tok[i + 2]), None
                    except (ValueError, IndexError):
                        pass
                if "pv" in tok and tok.index("pv") + 1 < len(tok):
                    try:
                        mv = chess.Move.from_uci(tok[tok.index("pv") + 1])
                        if mv in board.legal_moves:
                            partial_move = mv
                    except ValueError:
                        pass
            elif line.startswith("bestmove"):
                parts = line.split()
                if len(parts) < 2 or parts[1] in ("(none)", "0000"):
                    raise EngineError(f"Engine returned no move: {line!r}")
                try:
                    best_move = chess.Move.from_uci(parts[1])
                except ValueError as exc:
                    raise IllegalEngineMove(f"Unparseable engine move {parts[1]!r}") from exc
                if best_move not in board.legal_moves:
                    raise IllegalEngineMove(f"Engine move {parts[1]} is illegal in {board.fen()}")
                return SearchResult(best_move, "stockfish", depth, score_cp, mate,
                                    (time.perf_counter() - t0) * 1000)
