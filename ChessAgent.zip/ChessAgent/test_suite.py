"""
test_suite.py - run with:   python -m unittest -v test_suite
                       or:  python test_suite.py

Tests that need a real Stockfish are SKIPPED (and reported as skipped) if none is
found - set STOCKFISH_PATH first.  Measured timings are printed at the end.
"""
import json
import os
import subprocess
import sys
import tempfile
import textwrap
import threading
import time
import unittest

import chess

import config
from config import Config, find_stockfish
from engine_wrapper import EngineError, UCIEngine
from tournament_bot import (ChessBot, build_board, compute_hard_deadline, fallback_move)

HERE = os.path.dirname(os.path.abspath(__file__))
BOT = os.path.join(HERE, "tournament_bot.py")
SF = find_stockfish(os.environ.get("STOCKFISH_PATH") or None)
needs_sf = unittest.skipUnless(SF, "Stockfish not found (set STOCKFISH_PATH)")

TIMINGS = {}          # label -> milliseconds
FAKE = {"path": None, "dir": None}

FAKE_ENGINE_SRC = textwrap.dedent('''
    import sys, time
    mode = sys.argv[1]
    if mode == "nouci":
        time.sleep(60)
    for line in sys.stdin:
        line = line.strip()
        if line == "uci":
            print("id name FakeEngine"); print("option name Threads type spin default 1 min 1 max 8")
            print("option name Hash type spin default 16 min 1 max 1024"); print("uciok", flush=True)
        elif line == "isready":
            print("readyok", flush=True)
        elif line.startswith("go"):
            if mode == "hang":
                time.sleep(60)
            elif mode == "crash":
                sys.exit(1)
            elif mode == "illegal":
                print("bestmove a1a1", flush=True)
            elif mode in ("stoppable", "partial"):
                print("info depth 3 score cp 20 pv e2e4 e7e5", flush=True)
                if mode == "partial":
                    time.sleep(60)          # ignores "stop" -> must be killed
        elif line == "stop" and mode == "stoppable":
            print("bestmove e2e4", flush=True)
        elif line == "quit":
            break
''')


def setUpModule():
    FAKE["dir"] = tempfile.mkdtemp(prefix="fakeengine_")
    FAKE["path"] = os.path.join(FAKE["dir"], "fake_engine.py")
    with open(FAKE["path"], "w") as fh:
        fh.write(FAKE_ENGINE_SRC)


def tearDownModule():
    print("\n==== MEASURED TIMINGS (ms) ====")
    for k, v in TIMINGS.items():
        print(f"  {k:55s} {v:8.0f}")
    print(f"  (Stockfish used: {SF})")


def make_cfg(**kw):
    base = dict(stockfish_path=SF, time_limit_ms=1500, time_scope="move", safety_margin_ms=300)
    base.update(kw)
    cfg = Config(**base)
    cfg.validate()
    return cfg


def fake_cfg(mode, **kw):
    return make_cfg(engine_command=[sys.executable, FAKE["path"], mode], stockfish_path=None, **kw)


def timed(label, fn):
    t0 = time.perf_counter()
    out = fn()
    TIMINGS[label] = (time.perf_counter() - t0) * 1000
    return out


# =============================================================================
class TestConfigAndBudget(unittest.TestCase):
    def test_invalid_scope_rejected(self):
        with self.assertRaises(ValueError):
            Config(time_scope="whenever").validate()

    def test_threads_never_exceed_cpu_count(self):
        cfg = Config(threads=999)
        cfg.validate()
        self.assertLessEqual(cfg.threads, os.cpu_count() or 1)

    def test_explicit_missing_path_is_not_silently_replaced(self):
        self.assertIsNone(find_stockfish("/definitely/not/here/stockfish"))

    def test_build_preference_rank(self):
        self.assertLess(config._rank("sf-avx2.exe"), config._rank("sf-x86-64.exe"))

    def test_deadlines_by_scope(self):
        cfg = Config(time_limit_ms=5000, safety_margin_ms=700)
        cfg.validate()
        b = chess.Board()
        inv = compute_hard_deadline(cfg, "invocation", 100.0, 103.0, b, 0)
        mov = compute_hard_deadline(cfg, "move", 100.0, 103.0, b, 0)
        gam = compute_hard_deadline(cfg, "game", 100.0, 103.0, b, 0)
        self.assertAlmostEqual(inv, 104.3)          # counted from process start
        self.assertAlmostEqual(mov, 107.3)          # counted from the move request
        self.assertLess(gam - 103.0, 0.2)           # one move's share of a single 5 s game budget
        clk = compute_hard_deadline(cfg, "move", 100.0, 103.0, b, 0, {"movetime": 500})
        self.assertAlmostEqual(clk, 103.5)          # clocks can only shorten the deadline


class TestFallback(unittest.TestCase):
    def test_fallback_is_always_legal_and_finds_mate(self):
        b = chess.Board("6k1/5ppp/8/8/8/8/8/R5K1 w - - 0 1")
        mv = fallback_move(b)
        self.assertIn(mv, b.legal_moves)
        b.push(mv)
        self.assertTrue(b.is_checkmate())

    def test_fallback_handles_en_passant_and_promotion(self):
        for fen in ["4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 1", "8/P6k/8/8/8/8/8/K7 w - - 0 1",
                    "k7/8/8/8/8/8/p7/7K b - - 0 1"]:
            b = chess.Board(fen)
            self.assertIn(fallback_move(b), b.legal_moves)


# =============================================================================
@needs_sf
class TestRealStockfish(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.bot = ChessBot(make_cfg())
        TIMINGS["engine startup (handshake+options)"] = timed("engine startup (wall)", cls.bot.warm_up) and \
            cls.bot.engine.startup_ms
        assert cls.bot.engine.alive

    @classmethod
    def tearDownClass(cls):
        cls.bot.close()

    def move(self, fen, label=None, moves=()):
        b = build_board(fen, list(moves))
        res = timed(label or f"move: {fen[:30]}", lambda: self.bot.choose_move(b))
        return b, res

    def assert_legal(self, b, res):
        self.assertIsNotNone(res)
        self.assertIn(res.move, b.legal_moves)

    def test_initial_position(self):
        b, res = self.move(None, "move: initial position (1.5s limit)")
        self.assert_legal(b, res)
        self.assertEqual(res.source, "stockfish")
        self.assertLess(res.elapsed_ms, 1500)

    def test_black_to_move(self):
        b, res = self.move(None, "move: black to move", moves=["e2e4"])
        self.assertEqual(b.turn, chess.BLACK)
        self.assert_legal(b, res)

    def test_forced_mate_in_one(self):
        b, res = self.move("6k1/5ppp/8/8/8/8/8/R5K1 w - - 0 1", "move: mate in one")
        self.assert_legal(b, res)
        b.push(res.move)
        self.assertTrue(b.is_checkmate(), "engine should deliver Ra8#")

    def test_black_mate_in_one(self):
        b, res = self.move("r5k1/8/8/8/8/8/5PPP/6K1 b - - 0 1", "move: black mate in one")
        b.push(res.move)
        self.assertTrue(b.is_checkmate())

    def test_check_evasion(self):
        fen = "7k/8/8/8/8/5q2/8/7K w - - 0 1"
        b, res = self.move(fen, "move: check evasion (2 options)")
        self.assertTrue(b.is_check())
        self.assert_legal(b, res)
        b.push(res.move)
        b.turn = chess.WHITE
        self.assertFalse(b.is_attacked_by(chess.BLACK, b.king(chess.WHITE)), "king still in check")

    def test_single_legal_move_is_instant(self):
        b = chess.Board("k7/8/8/8/8/8/1q6/K7 w - - 0 1")
        self.assertEqual(b.legal_moves.count(), 1)
        res = timed("move: single legal move", lambda: self.bot.choose_move(b))
        self.assertEqual(res.source, "forced")
        self.assertEqual(res.move.uci(), "a1b2")
        self.assertLess(res.elapsed_ms, 50)

    def test_terminal_positions_return_none(self):
        for name, fen in [("checkmate", "rnb1kbnr/pppp1ppp/8/4p3/6Pq/5P2/PPPPP2P/RNBQKBNR w KQkq - 1 3"),
                          ("stalemate", "7k/5Q2/6K1/8/8/8/8/8 b - - 0 1"),
                          ("insufficient material", "8/8/8/4k3/8/8/3K4/8 w - - 0 1")]:
            with self.subTest(name):
                self.assertIsNone(self.bot.choose_move(chess.Board(fen)))

    def test_promotion(self):
        # promotion is the ONLY way to mate in one (white pawn a7 / black pawn a2)
        for fen in ["8/P7/8/8/8/8/8/k1K5 w - - 0 1", "K1k5/8/8/8/8/8/p7/8 b - - 0 1"]:
            b, res = self.move(fen, "move: promotion mate")
            self.assert_legal(b, res)
            self.assertIsNotNone(res.move.promotion, "should promote")
            b.push(res.move)
            self.assertTrue(b.is_checkmate(), "promotion should deliver mate")

    def test_castling_and_history(self):
        moves = "e2e4 e7e5 g1f3 b8c6 f1c4 g8f6 e1g1".split()     # white castles kingside
        b, res = self.move(None, "move: after castling", moves=moves)
        self.assertEqual(b.king(chess.WHITE), chess.G1)
        self.assert_legal(b, res)
        b2, res2 = self.move("r3k2r/pppppppp/8/8/8/8/PPPPPPPP/R3K2R w KQkq - 0 1", "move: castling available")
        self.assertIn(chess.Move.from_uci("e1g1"), b2.legal_moves)
        self.assert_legal(b2, res2)

    def test_en_passant(self):
        b, res = self.move("4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 1", "move: en passant available")
        self.assertIn(chess.Move.from_uci("e5d6"), b.legal_moves)
        self.assert_legal(b, res)
        b2, res2 = self.move(None, "move: en passant via history", moves="e2e4 a7a6 e4e5 d7d5".split())
        self.assertTrue(b2.has_legal_en_passant())
        self.assert_legal(b2, res2)

    def test_engine_is_reused_not_restarted(self):
        pid1 = self.bot.engine._proc.pid
        self.bot.choose_move(chess.Board())
        self.assertEqual(pid1, self.bot.engine._proc.pid)

    def test_respects_deadline_in_bot(self):
        cfg = make_cfg(time_limit_ms=1000, safety_margin_ms=200)
        bot = ChessBot(cfg)
        bot.warm_up()
        t0 = time.perf_counter()
        res = bot.choose_move(chess.Board())
        total = (time.perf_counter() - t0) * 1000
        bot.close()
        TIMINGS["move: 1.0s limit, scope=move (must be <1000)"] = total
        self.assertLess(total, 1000)
        self.assertEqual(res.source, "stockfish")


# =============================================================================
class TestFailureHandling(unittest.TestCase):
    """Fake engines that misbehave. Each must still return a LEGAL move before the deadline."""

    def run_mode(self, mode, limit=1000, margin=200, **kw):
        cfg = fake_cfg(mode, time_limit_ms=limit, safety_margin_ms=margin, **kw)
        bot = ChessBot(cfg)
        b = chess.Board()
        t0 = time.perf_counter()
        try:
            res = bot.choose_move(b)
        finally:
            total = (time.perf_counter() - t0) * 1000
            bot.close()
        TIMINGS[f"failure: {mode} (limit {limit}ms)"] = total
        return b, res, total

    def test_engine_hangs_on_search(self):
        b, res, total = self.run_mode("hang")
        self.assertEqual(res.source, "fallback")
        self.assertIn(res.move, b.legal_moves)
        self.assertLess(total, 1000)

    def test_engine_never_answers_uci(self):
        b, res, total = self.run_mode("nouci")
        self.assertEqual(res.source, "fallback")
        self.assertIn(res.move, b.legal_moves)
        self.assertLess(total, 1000)

    def test_engine_crashes(self):
        b, res, total = self.run_mode("crash")
        self.assertEqual(res.source, "fallback")
        self.assertIn(res.move, b.legal_moves)

    def test_engine_returns_illegal_move(self):
        b, res, total = self.run_mode("illegal")
        self.assertEqual(res.source, "fallback")
        self.assertIn(res.move, b.legal_moves)

    def test_stop_command_used_before_deadline(self):
        b, res, total = self.run_mode("stoppable")
        self.assertEqual(res.source, "stockfish")
        self.assertEqual(res.move.uci(), "e2e4")
        self.assertLess(total, 1000)

    def test_partial_result_used_when_engine_ignores_stop(self):
        b, res, total = self.run_mode("partial")
        self.assertEqual(res.source, "stockfish-partial")
        self.assertEqual(res.move.uci(), "e2e4")
        self.assertLess(total, 1000)

    def test_no_fallback_raises(self):
        cfg = fake_cfg("crash", fallback=False)
        bot = ChessBot(cfg)
        with self.assertRaises(EngineError):
            bot.choose_move(chess.Board())
        bot.close()

    def test_missing_binary_falls_back(self):
        cfg = make_cfg(stockfish_path="/nonexistent/dir/stockfish")
        bot = ChessBot(cfg)
        b = chess.Board()
        t0 = time.perf_counter()
        res = bot.choose_move(b)
        TIMINGS["failure: missing binary"] = (time.perf_counter() - t0) * 1000
        self.assertEqual(res.source, "fallback")
        self.assertIn(res.move, b.legal_moves)
        self.assertIn("not found", bot.last_error.lower())

    def test_missing_binary_no_fallback_raises(self):
        bot = ChessBot(make_cfg(stockfish_path="/nonexistent/dir/stockfish", fallback=False))
        with self.assertRaises(EngineError):
            bot.choose_move(chess.Board())

    def test_engine_restarts_after_kill(self):
        cfg = fake_cfg("hang", time_limit_ms=1200, safety_margin_ms=200)
        bot = ChessBot(cfg)
        bot.choose_move(chess.Board())                 # hang -> engine killed
        self.assertFalse(bot._engine_alive())
        t0 = time.perf_counter()
        res = bot.choose_move(chess.Board())           # must not block forever
        self.assertLess((time.perf_counter() - t0) * 1000, 1200)
        self.assertIn(res.move, chess.Board().legal_moves)
        bot.close()


# =============================================================================
@needs_sf
class TestCommandLine(unittest.TestCase):
    """End-to-end through real subprocesses (what a tournament harness would do)."""

    def run_cli(self, *args, timeout=15, env_extra=None):
        env = dict(os.environ, STOCKFISH_PATH=SF)
        if env_extra:
            env.update(env_extra)
        t0 = time.perf_counter()
        p = subprocess.run([sys.executable, BOT, *args], capture_output=True, text=True,
                           timeout=timeout, env=env)
        return p, (time.perf_counter() - t0) * 1000

    def test_fen_mode_default_5s_budget_wall_clock(self):
        p, wall = self.run_cli("fen", "--fen", "startpos")
        TIMINGS["CLI fen startpos, DEFAULT 5000ms (wall, incl. python start)"] = wall
        self.assertEqual(p.returncode, 0, p.stderr)
        move = p.stdout.strip()
        self.assertEqual(len(p.stdout.strip().splitlines()), 1, "stdout must contain exactly one line")
        self.assertIn(chess.Move.from_uci(move), chess.Board().legal_moves)
        self.assertLess(wall, 5000, "must finish inside 5 s when the limit covers the whole invocation")

    def test_fen_mode_json_reports_timing(self):
        p, wall = self.run_cli("fen", "--fen", "startpos", "--time-ms", "2000", "--json")
        data = json.loads(p.stdout)
        TIMINGS["CLI fen startpos, 2000ms limit (wall)"] = wall
        self.assertLess(wall, 2000)
        self.assertEqual(data["source"], "stockfish")

    def test_fen_mode_mate_in_one(self):
        p, wall = self.run_cli("fen", "--fen", "6k1/5ppp/8/8/8/8/8/R5K1 w - - 0 1", "--time-ms", "2000")
        self.assertEqual(p.stdout.strip(), "a1a8")

    def test_fen_mode_terminal_position(self):
        p, _ = self.run_cli("fen", "--fen", "7k/5Q2/6K1/8/8/8/8/8 b - - 0 1")
        self.assertEqual(p.returncode, 2)
        self.assertEqual(p.stdout.strip(), "")

    def test_fen_mode_bad_input(self):
        p, _ = self.run_cli("fen", "--fen", "not a fen")
        self.assertEqual(p.returncode, 3)
        self.assertEqual(p.stdout.strip(), "")
        p, _ = self.run_cli("fen", "--fen", "startpos", "--moves", "e2e5")
        self.assertEqual(p.returncode, 3)

    def test_fen_mode_missing_binary_uses_fallback_in_time(self):
        p, wall = self.run_cli("fen", "--fen", "startpos", env_extra={"STOCKFISH_PATH": "/nope/stockfish"})
        TIMINGS["CLI fen, missing binary -> fallback (wall)"] = wall
        self.assertEqual(p.returncode, 0)
        self.assertIn(chess.Move.from_uci(p.stdout.strip()), chess.Board().legal_moves)
        self.assertLess(wall, 5000)

    def test_fen_mode_missing_binary_no_fallback(self):
        p, _ = self.run_cli("--no-fallback", "fen", "--fen", "startpos",
                            env_extra={"STOCKFISH_PATH": "/nope/stockfish"})
        self.assertEqual(p.returncode, 4)
        self.assertEqual(p.stdout.strip(), "")

    def uci_session(self, lines, expect_bestmoves, extra_args=(), timeout=15):
        """Interactive UCI session. Returns (stdout_lines, [latency_ms per bestmove])."""
        p = subprocess.Popen([sys.executable, BOT, *extra_args, "uci"], stdin=subprocess.PIPE,
                             stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True,
                             env=dict(os.environ, STOCKFISH_PATH=SF))
        out_lines, latencies = [], []
        try:
            for item in lines:
                if isinstance(item, (int, float)):
                    time.sleep(item)
                    continue
                t_send = time.perf_counter()
                p.stdin.write(item + "\n")
                p.stdin.flush()
                if item.startswith("isready"):
                    while True:
                        l = p.stdout.readline().strip()
                        out_lines.append(l)
                        if l == "readyok":
                            break
                elif item == "uci":
                    while True:
                        l = p.stdout.readline().strip()
                        out_lines.append(l)
                        if l == "uciok":
                            break
                elif item.startswith("go"):
                    t_go = t_send
                    if item.startswith("go infinite") or "NOWAIT" in item:
                        continue
                    while True:
                        l = p.stdout.readline().strip()
                        out_lines.append(l)
                        if l.startswith("bestmove"):
                            latencies.append((time.perf_counter() - t_go) * 1000)
                            break
                elif item == "stop":
                    while True:
                        l = p.stdout.readline().strip()
                        out_lines.append(l)
                        if l.startswith("bestmove"):
                            latencies.append((time.perf_counter() - t_send) * 1000)
                            break
            p.stdin.write("quit\n")
            p.stdin.flush()
            p.wait(timeout=5)
        finally:
            if p.poll() is None:
                p.kill()
            for stream in (p.stdin, p.stdout):
                try:
                    stream.close()
                except Exception:
                    pass
        return out_lines, latencies

    def test_uci_protocol_clean_stdout_and_legal_moves(self):
        lines = ["uci", "isready", "ucinewgame", "isready", "position startpos", "go movetime 500",
                 "position startpos moves e2e4", "go movetime 500",              # black to move
                 "position startpos moves e2e4 e7e5 g1f3 b8c6 f1c4 g8f6 e1g1", "go movetime 500",
                 "position startpos moves e2e4 a7a6 e4e5 d7d5", "go wtime 3000 btime 3000 winc 0 binc 0"]
        out, lat = self.uci_session(lines, 4)
        allowed = ("id ", "uciok", "readyok", "info ", "bestmove ")
        for l in out:
            self.assertTrue(l.startswith(allowed), f"non-UCI line on stdout: {l!r}")
        moves = [l.split()[1] for l in out if l.startswith("bestmove")]
        self.assertEqual(len(moves), 4)
        for fen_moves, mv in zip(["", "e2e4", "e2e4 e7e5 g1f3 b8c6 f1c4 g8f6 e1g1",
                                  "e2e4 a7a6 e4e5 d7d5"], moves):
            b = build_board(None, fen_moves.split())
            self.assertIn(chess.Move.from_uci(mv), b.legal_moves)
        TIMINGS["UCI: warm engine, go movetime 500 -> bestmove (max)"] = max(lat[:3])
        TIMINGS["UCI: go wtime 3000 (clock-based) -> bestmove"] = lat[3]
        for l in lat[:3]:
            self.assertLess(l, 1000)
        self.assertLess(lat[3], 3000 * 0.5)
        depths = [int(l.split()[2]) for l in out if l.startswith("info depth")]
        self.assertGreaterEqual(depths[-1], 8, "clock-based search must still be a real search")
        TIMINGS["UCI: depth reached with go wtime 3000"] = depths[-1]

    def test_uci_infinite_is_capped_and_stop_works(self):
        out, lat = self.uci_session(["uci", "isready", "position startpos", "go infinite", 0.3, "stop"], 1)
        self.assertTrue(any(l.startswith("bestmove") for l in out))
        TIMINGS["UCI: go infinite + stop after 0.3s -> bestmove"] = lat[0]
        self.assertLess(lat[0], 1000)
        # without "stop" the search must still end by itself (never unlimited)
        p = subprocess.Popen([sys.executable, BOT, "--time-ms", "1500", "--scope", "move", "uci"],
                             stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                             text=True, env=dict(os.environ, STOCKFISH_PATH=SF))
        p.stdin.write("uci\nisready\nposition startpos\n")
        p.stdin.flush()
        while p.stdout.readline().strip() != "readyok":
            pass
        t0 = time.perf_counter()
        p.stdin.write("go infinite\n")
        p.stdin.flush()
        line = ""
        while not line.startswith("bestmove"):
            line = p.stdout.readline().strip()
        waited = (time.perf_counter() - t0) * 1000
        p.stdin.write("quit\n")
        p.stdin.flush()
        p.wait(timeout=5)
        p.stdin.close()
        p.stdout.close()
        TIMINGS["UCI: go infinite WITHOUT stop, 1500ms cap"] = waited
        self.assertLess(waited, 1500)

    def test_uci_no_overlapping_searches(self):
        p = subprocess.Popen([sys.executable, BOT, "uci"], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                             stderr=subprocess.DEVNULL, text=True, env=dict(os.environ, STOCKFISH_PATH=SF))
        p.stdin.write("uci\nisready\nposition startpos\ngo movetime 600\ngo movetime 600\n")
        p.stdin.flush()
        time.sleep(1.5)
        p.stdin.write("quit\n")
        p.stdin.flush()
        out = p.stdout.read()
        p.wait(timeout=5)
        p.stdin.close()
        p.stdout.close()
        self.assertEqual(out.count("bestmove"), 1, out)

    def test_uci_bad_position_does_not_crash(self):
        out, lat = self.uci_session(["uci", "isready", "position startpos moves e2e5", "go movetime 300",
                                     "position startpos", "go movetime 300"], 2)
        moves = [l for l in out if l.startswith("bestmove")]
        self.assertEqual(moves[0], "bestmove (none)")
        self.assertNotEqual(moves[1], "bestmove (none)")

    def test_uci_terminal_position(self):
        out, lat = self.uci_session(["uci", "isready",
                                     "position fen 7k/5Q2/6K1/8/8/8/8/8 b - - 0 1", "go movetime 300"], 1)
        self.assertIn("bestmove (none)", out)

    def test_find_and_check_commands(self):
        p, wall = self.run_cli("check")
        TIMINGS["CLI check (handshake + 300ms search, wall)"] = wall
        self.assertEqual(p.returncode, 0, p.stdout + p.stderr)
        self.assertIn("ENGINE OK", p.stdout)
        p, _ = self.run_cli("find")
        self.assertEqual(p.returncode, 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
